package location.master.services;

public class CatVehicule {
	
	Integer code;
	String libelle;
	Float prix;
	
	public Integer getcode() {
		return code;
	}

	public void setcode(Integer code) {
		this.code = code;
	}
	
	public String getlibelle() {
		return libelle;
	}

	public void setlibelle(String libelle) {
		this.libelle = libelle;
	}
	
	public Float getprix() {
		return prix;
	}

	public void setprix(Float prix) {
		this.prix = prix;
	}

}
